/*
 *	"nlith.c"
 *
 *		- main program module
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#define		MAINMODULE
#include	"nlith.h"


#ifdef	ANSI
void
#endif	/* ANSI */
main(argc, argv)
int		argc;
char	**argv;
{
	int			i;
	char		*chp;
	BOOLEAN		replay;

	initvar1();
	if ((chp = getenv("NLITH")) != NULL) {
		getoptions(chp);
	}
	for (i = 1; i < argc; i++) {
		getoptions(argv[i]);
	}
	initvar2();
	if (cryptonly) {
		cryptstrings();
		nlexit(0);
	} else if (scoreonly) {
		printrecord();
		nlexit(0);
	} else {
		checkrecord();
	}
	warnnext();
	whoareyou();
	setsig();
	control();
	pictureon();
	replay = TRUE;

	while (replay) {
		setvar();
		wipegarvage();
		redraw();
		moonmsg();
		while (genelith()) {			/* if available to generate nlith */
			while (droplith(TRUE)) {	/* if available falldown */
				movewormone();			/* worm's action */
				movelithone();			/* operate nlith, quitting by timeout */
			}
			setgarvage();				/* make dead nlith a junk tile */
			checkstack();				/* compress complete lines */
			flushstrings(10);			/* display message */
		}
		addbonus();
		printrecord();
		replay = query("play again");
	}
	nlexit(0);
}


#ifdef	ANSI
void
#endif	/* ANSI */
upscore()
{
	score += (long)(scorestep);
	if (rnd(10) == 0) {
		scorestep++;
	}
}


BOOLEAN
isevil(fact)
	int		fact;
{
	if (istraining || wizard || evilpoint <= rnd(fact + (pmoon << 3))) {
		return (FALSE);
	}
	return (TRUE);
}


BOOLEAN
isholy()
{
	int		i;

	if(istraining) {
		return (FALSE);
	}
	holypoint -= rnd(4);
	if (!wizard && holypoint < rnd(100 + (pmoon << 3))) {
		dispstrings(12);		/* failed to decrease e.p. or polylith */
		return (FALSE);
	}
	if (rnd(24 - pmoon) < 8) {
		i = rnd(10);
		holypoint -= i * (rnd(4) + 1);
		evilpoint -= i;
		dispstrings(11);		/* succeeded to decrease e.p. */
		return (FALSE);
	}

	return (TRUE);				/* succeeded to polylith */
}


#ifdef	ANSI
void
#endif	/* ANSI */
addbonus()
{
	orgscore = score;
	if (!istraining) {
		score += (long)(holypoint) * 10L - (long)(evilpoint) * 40L;
	}
	dispscore();
}


#ifdef	ANSI
void
#endif	/* ANSI */
docmd(ch)
	char	ch;
{
	if ((int)(ch) < 0) {
		return;
	}
	switch (keyalias(ch)) {

	case FN_LEFT :
		moveone++;
		swinglith(-2);
		break;

	case FN_RIGHT :
		moveone++;
		swinglith(2);
		break;
	
	case FN_ROTA :
		moveone++;
		rotlith();
		break;
	
	case FN_DROP :
		falllith();
		break;

	case FN_PANIC :
		moveone++;
		panic();
		break;

	case FN_PRAY :
		moveone++;
		polylith();
		break;

	case FN_QUIT :
		moveone++;
		moveone++;
		if (query("really quit")) {
			addbonus();
			printrecord();
			nlexit(0);
		}
		break;

	case FN_BEEP :
		belsw = ! belsw;
		break;

	case FN_INVOKE :
		shellinvoke();
		break;

	case FN_LOGO :
		logotype = ! logotype;
		redraw();
		break;

	case FN_COLOUR :
		coloured = ! coloured;

	case FN_REDRAW :
		redraw();
		break;

	case FN_JUMP :
		isjump = ! isjump;
		break;
	}
}
