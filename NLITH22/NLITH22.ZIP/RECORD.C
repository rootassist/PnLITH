/*
 *	"record.c"
 *
 *		- high-score record file reading and writing functions
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


/*
 *	printrecord()
 *	- operate recorde file.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
printrecord()
{
	if (istraining) {
		if (scoreonly) {
			precone(0, PRA_DISP);
		} else {
			precone(0, PRA_REC);
		}
	} else {
		if (scoreonly) {
			precone(CURRENT_DAYS, PRA_DISP);
			printf("\n");
			precone(0           , PRA_DISP);
		} else {
			precone(CURRENT_DAYS, PRA_REC);
			precone(0           , PRA_REC);
			if (query("show lately")) {
				precone(CURRENT_DAYS, PRA_DISP);
			}
			if (query("show best")) {
				precone(0           , PRA_DISP);
			}
		}
	}
}


/*
 *	checkrecord()
 *	- operate recorde file.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
checkrecord()
{
	if (istraining) {
		checkrecone(0, "recordtr.nlt");
	} else {
		checkrecone(0           , "record.nlt");
		checkrecone(CURRENT_DAYS, "recordcr.nlt");
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
checkrecone(current, fname)
	int		current;
	char	*fname;
{
		int		stat;

	if ((stat = precone(current, PRA_CHECK)) == PRR_RERROR) {
		fprintf(stderr,
		"* No \"%s%s\" or read error or empty. I will create new one.\n",
			filepath, fname);
		warn = TRUE;
	} else if (stat == PRR_WERROR) {
		fprintf(stderr,
		"* Write error on \"%s%s\". Your score won't be remained on it.\n",
			filepath, fname);
		warn = TRUE;
	} else if (stat == PRR_BADFORM) {
		fprintf(stderr,
		"* Bad format on \"%s%s\". All or a part of it will be lost.\n",
			filepath, fname);
		warn = TRUE;
	}
}


/*
 *	precone()
 *	- read and (check or (print (and write))) one record file.
 *	  the target file is :
 *	   "record.nlt"   if not training mode and "current" is over 0,
 *	   "recordcr.nlt" if not training mode and "current" is 0,
 *	   "recordtr.nlt" if training mode.
 */
int
precone(current, mode)
	int			current, mode;
{
	int			hnum, myname, rank,
				hlines[HMAX], hblocks[HMAX],
				hyy[HMAX], hmm[HMAX], hdd[HMAX];
	long int	hscore[HMAX], horg[HMAX], l;
	register	int		i, j, stl;
	char		hname[HMAX][P_NAME_MAX], fbuf[BUFLEN], crybuf[BUFLEN],
				scorefile[F_NAME_MAX],
				*chp,
				*brankline =
			  "                                                             ";
	BOOLEAN		dowrite, rightfile;
	FILE		*fp;
	struct tm	*lt;

	hnum =
	myname = 0;
	rank = -1;
	dowrite = (mode == PRA_REC) && (! wizard) && (genn != 1);
	rightfile = TRUE;

	getgamedir(scorefile, filepath);
	if (istraining) {
		strcat(scorefile, "recordtr.nlt");
	} else if (current < 1) {
		strcat(scorefile, "record.nlt");
	} else {
		strcat(scorefile, "recordcr.nlt");
	}
	lt = getdt();
	if ((fp = fbopen(scorefile, "r")) != NULL) {
		fgetc(fp);

/* ---- read SCOREFILE ---- */

		for ( ; hnum < HMAX - 1 && nlfgets(crybuf, BUFLEN, fp) != EOF; ) {
			nldecrypt(crybuf, fbuf);

			if ((chp = strchr(fbuf, ' ')) == NULL ||
			   P_NAME_MAX <= (stl = chp - fbuf)) {
				rightfile = FALSE;
				break;
			}
			strncpy(hname[hnum], fbuf, stl);
			hname[hnum][stl] = NULL;

			chp++;
			if (! isnumber(*chp)) {
				rightfile = FALSE;
				break;
			}
			l = atol(chp);
			if ((chp = strchr(chp, ' ')) == NULL) {
				rightfile = FALSE;
				break;
			}
			hscore[hnum] = l;

			chp++;
			if ((! isnumber(*chp))) {
				rightfile = FALSE;
				break;
			}
			l = atol(chp);
			if ((chp = strchr(chp, ' ')) == NULL) {
				rightfile = FALSE;
				break;
			}
			horg[hnum] = l;

			if ((hblocks[hnum] = getintfld(&chp)) < 0 ||
				(hlines[hnum]  = getintfld(&chp)) < 0 ||
				(hyy[hnum]     = getintfld(&chp)) < 0 ||
				(hmm[hnum]     = getintfld(&chp)) < 0
			   ) {
				rightfile = FALSE;
				break;
			}

			chp++;
			if ((!isnumber(*chp))) {
				rightfile = FALSE;
				break;
			}
			hdd[hnum] = atoi(chp);

			if (current < 1 ||
				abdate(lt -> tm_year, (lt -> tm_mon) + 1, lt -> tm_mday)
				- abdate(hyy[hnum], hmm[hnum], hdd[hnum])
				<= (long)(current)) {
				hnum++;
			}
		}
		fclose(fp);
	}
	if (mode == PRA_CHECK) {
		if ((fp = fbopen(scorefile, "a")) == NULL) {
			return (PRR_WERROR);
		} else {
			fclose(fp);
		}
		if (hnum == 0) {
			return (PRR_RERROR);
		}
		if (! rightfile) {
			return (PRR_BADFORM);
		}
		return (PRR_OK);
	}

/*** find 'rank' where to add name & score ***/

	if (scoreonly) {
		dowrite = FALSE;
	} else if (mode == PRA_DISP) {	/* when PRA_DISP, the score is already
									 * exists on scorefile.  */
		for (i = 0; i < hnum; i++) {
			if (hscore[i] == score) {
				rank = i;
				break;
			}
		}
	}
	if ((! scoreonly) && rank < 0) {
		for (i = 0; i < hnum; i++) {
			if (hscore[i] <= score) {
				rank = i;
				break;
			}
			if (strcmp(hname[i], player) == 0)
				myname++;
		}
		if (i == hnum) {				/* lower than lowest record */
			rank = hnum;
			if (HMAX - 1 <= rank)
				dowrite = FALSE;
		}
		if (++myname <= 5) {
			for (i = rank; i < hnum; i++) {	/* 'i' is where 6th name appears */
				if (strcmp(hname[i], player) == 0)
					if (5 < ++myname) {					/* delete 6th name */
						for (j = i; j < hnum - 1; j++) {
							strcpy(hname[j], hname[j + 1]);
							hscore[j] = hscore[j + 1];
							horg[j] = horg[j + 1];
							hblocks[j] = hblocks[j + 1];
							hlines[j] = hlines[j + 1];
							hyy[j] = hyy[j + 1];
							hmm[j] = hmm[j + 1];
							hdd[j] = hdd[j + 1];
						}
						hnum--;
						i--;
					/*	myname--;	---- no needed (already over 6th) */
					}
			}
		} else {						/* lower than 5th mypoint */
			dowrite = FALSE;
		}
	
		for (j = hnum; rank < j; j--) {	/* add myname as 'rank'th record */
			strcpy(hname[j], hname[j - 1]);
			hscore[j] = hscore[j - 1];
			horg[j] = horg[j - 1];
			hblocks[j] = hblocks[j - 1];
			hlines[j] = hlines[j - 1];
			hyy[j] = hyy[j - 1];
			hmm[j] = hmm[j - 1];
			hdd[j] = hdd[j - 1];
		}
		if (hnum < HMAX - 1 ||			/* deleted 6th myrecord */
		   rank == hnum) {				/* just an unranked record */
			hnum++;
		}
		strcpy(hname[rank], player);
		hscore[rank] = score;
		horg[rank] = orgscore;
		hblocks[rank] = blocks;
		hlines[rank] = erasedlines;
		hyy[rank] = lt -> tm_year;
		hmm[rank] = (lt -> tm_mon) + 1;
		hdd[rank] = lt -> tm_mday;
	}

/*** display record ***/

	if (mode == PRA_DISP) {
		if (scoreonly) {
			printf("\n");
		} else {
			moveto(0, 17);
		}
		if (!istraining) {
			if (current < 1) {
				printf("               *** Best warriors' record ***\n");
			} else {
				printf("                *** Record of last %ddays ***\n",
						current);
			}
		} else {
			printf("                *** Best cadets' record ***\n");
		}
		if (!scoreonly) {
			moveto(1, 17);
			printf("%s", brankline);
		} else {
			printf("\n");
		}

		for (i = 0; i < hnum; i++) {			/* print score record */
			if (!scoreonly) {
				moveto(2 + i, 17);
			}
			if (i == rank) {
				colour(7);
			}
			printf("%2d. %6ld / %6ld (%4dblocks, %3dlines) %16s",
					i + 1, hscore[i], horg[i], hblocks[i], hlines[i], hname[i]);
			if (score == hscore[i]) {
				norm();
			}
			if (!scoreonly) {
				printf("   ");
			}
			printf("\n");
		}
		if (!scoreonly) {
			moveto(2 + hnum, 17);
			printf("%s", brankline);
		}
	}

/*** record on file ***/

	if (dowrite) {
		if ((fp = fbopen(scorefile, "w")) != NULL) {	/* write to file */
			fprintf(fp, "%c", 0x1a);
			for (i = 0; i < hnum; i++) {
				sprintf(fbuf, "%s %ld %ld %d %d %d %d %d",
						hname[i], hscore[i], horg[i], hblocks[i], hlines[i],
						hyy[i], hmm[i], hdd[i]
					   );
				nlencrypt(fbuf, crybuf);
				nlfputs(crybuf, fp);
			}
			fclose(fp);
		}
	}
	return (PRR_OK);	/* no meaning */
}
