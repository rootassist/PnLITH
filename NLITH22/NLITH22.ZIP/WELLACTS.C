/*
 *	"wellacts.c"
 *
 *		- functions describing well's actions
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


#ifdef	ANSI
void
#endif	/* ANSI */
setgarvage()
{
	int				maxheight, brankcount;
	register int	i;

	maxheight = 0;
	for (i = 0; i < lithn; i++) {
		map[moving.x[i]    ][moving.y[i]] = moving.ch1;
		mapattr[moving.x[i]    ][moving.y[i]] = moving.attr;
		map[moving.x[i] + 1][moving.y[i]] = moving.ch2;
		mapattr[moving.x[i] + 1][moving.y[i]] = moving.attr;
		if (maxheight < moving.y[i]) {
			maxheight = moving.y[i];
		}
	}
	for (i = brankcount = 0; i < lithn; i++) {
		if (0 < moving.y[i]) {
			if (map[moving.x[i]    ][moving.y[i] - 1] == BLANK) {
				brankcount++;
			}
			if (map[moving.x[i] + 1][moving.y[i] - 1] == BLANK) {
				brankcount++;
			}
		}
	}
	evilpoint += (brankcount >> 1);
	if (0 < brankcount) {
		dispstrings(1);		/* evil allocation */
	}
	if (welldepth - MAXLITHN - 2 < maxheight) {
		dispstrings(5);		/* almost gameover */
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
wipegarvage()
{
	register int	x, y;
	int				pattern;

	for (y = 0; y < height; y++) {
		for (x = 0; x < wellwidth; x++, x++) {
			if (rnd(10) < IGARV_FACTOR) {
				if (genn == 0) {
					pattern = rnd(MAXINIINFO);
				} else {
					pattern = basinfo[genn - 1] + rnd(patinfo[genn - 1]);
				}
				map[x    ][y] = iniinfo[pattern].shape.ch1;
				map[x + 1][y] = iniinfo[pattern].shape.ch2;
				mapattr[x    ][y] =
				mapattr[x + 1][y] = iniinfo[pattern].shape.attr;
			} else {
				map[x    ][y] =
				map[x + 1][y] = BLANK;
			}
		}
	}
	for (y = height; y < welldepth; y++) {
		for (x = 0; x < wellwidth; x++) {
			map[x][y] = BLANK;
		}
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
checkstack()
{
	register int	x, ymov, y;
	int				i, yfirst, spotcount, wc;

	dispstrings(7);		/* put a block */
	yfirst = -1;
	for (y = 0; y < welldepth; y++) {
		for (x = wc = 0; x < wellwidth; x++) {
			if (map[x][y] == BLANK ||
				(map[x][y] == wormbody || map[x][y] == wormhead
				) && mapattr[x][y] == wormalcolour
			   ) {
				if (!wizard || wc == 2) {
					break;
				} else {
					wc++;
				}
			}
		}
		if (x == wellwidth) {
			bel();
			holypoint += 2;
			erasedlines++;
			upscore();
			if (yfirst == -1) {
				yfirst = y;
			}
			for (ymov = y; ymov < welldepth - 1; ymov++) {
				for (x = 0; x < wellwidth; x++) {
					map[x][ymov] = map[x][ymov + 1];
					mapattr[x][ymov] = mapattr[x][ymov + 1];
				}
			}
			for (x = 0; x < wellwidth; x++) {
				map[x][welldepth - 1] = BLANK;
			}
			for (i = 0; i < wormlen; i++) {	/* drop upper worm */
				if (y < wormy[i]) {
					wormy[i]--;
				}
			}
			if (0 < y) {		/* find new spots */
				for (x = spotcount = 0; x < wellwidth; x++) {
					if (map[x][y - 1] == BLANK) {
						for (ymov = y; ymov < welldepth; ymov++) {
							if (map[x][ymov] != BLANK) {
								break;		/* not a spot (blocks above) */
							}
						}
						if (ymov == welldepth) {
							spotcount++;
						}
					}
				}
				spotcount >>= 1;
				evilpoint -= spotcount;
				holypoint += spotcount;
				if (0 < spotcount) {
					dispstrings(8);		/* make a spot */
				}
			}
			y--;	/* to check 1 line above */
		}
	}
	if (0 <= yfirst) {
		drawgarvages(yfirst);
	}
	blocks++;
	holypoint++;
	moveone -= (wellwidth >> 2) + 2;	/* sub avarage action */
	if (0 < moveone) {
		evilpoint += (moveone >> 1);	/* add overaction / 2 */
		dispstrings(2);		/* evil moving */
	}
	moveone = 0;
	upscore();
	dispscore();
	if (istraining) {
		speedup(1, 2);
	} else {
		speedup(8, 2);
	}
}
