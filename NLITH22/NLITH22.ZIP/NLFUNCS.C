/*
 *	"nlfuncs.c"
 *
 *		- miscellenious functions
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


#ifdef	ANSI
void
#endif	/* ANSI */
fatal(fatalmsg)
char	*fatalmsg;
{
	fprintf(stderr, "(fatal) %s.\n", fatalmsg);
	nlexit(1);
}


#ifdef	ANSI
void
#endif	/* ANSI */
warnnext()
{
	char	ch;
	if (warn) {
		fprintf(stderr, "( RETURN to continue, any other key to abort )");
		if ((ch = Getchar()) != CR && ch != LF) {
			fprintf(stderr, "\n");
			nlexit(1);
		}
		fprintf(stderr, "\n");
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
nlexit(status)
	int	status;
{
	uncontrol();
	pictureon();
	if (!scoreonly && status == 0) {
		moveto(23, 0);
	}
	exit(status);
}


BOOLEAN
query(querymsg)
	char	*querymsg;
{
	char	ent;
	BOOLEAN	ans;

	curon();
	moveto(23, 62);
	printf("%s(y/n)?", querymsg);
	while(TRUE) {
		ent = Getchar();
		if((ent = Tolower(ent)) == 'y') {
			ans = TRUE;
			break;
		} else if(ent == 'n') {
			ans = FALSE;
			break;
		} else {
			bel();
		}
	}
	moveto(23, 62);
	printf("                 ");
	curoff();
	return (ans);
}
 

#ifdef	ANSI
void
#endif	/* ANSI */
getoptions(chp)
	char	*chp;
{
	register int	i;
	int				stl;
	register char	*chp1;

	while(*chp != NULL) {
		if(*chp == '-') {
			chp++;
			while (*chp != NULL && *chp != ';') {
				switch(Tolower(*chp)) {

				case 'a' :
					ansiwrite = TRUE;
					chp++;
					break;

				case 's' :
					scoreonly = TRUE;
					chp++;
					break;

				case 't' :
					istraining = TRUE;
					chp++;
					break;

				case 'j' :
					isjump = TRUE;
					chp++;
					break;

				case 'v' :
					rotincr = 3;
					chp++;
					break;

				case 'c' :
					cryptonly = TRUE;
					chp++;
					break;

				case 'd' :
					i = atoi(++chp);
					if (i < WELLDEPTH_MIN) {
						welldepth = WELLDEPTH_MIN;
					} else if (WELLDEPTH_MAX < i) {
						welldepth = WELLDEPTH_MAX;
					} else {
						welldepth = i;
					}
					if ((chp1 = strchr(chp, ';')) != NULL) {
						chp = chp1;
					} else {
						chp += strlen(chp);
					}
					break;

				case 'w' :
					i = atoi(++chp);
					if (i < WELLWIDTH_MIN) {
						wellwidth = WELLWIDTH_MIN;
					} else if (WELLWIDTH_MAX < i) {
						wellwidth = WELLWIDTH_MAX;
					} else {
						wellwidth = i;
					}
					if ((chp1 = strchr(chp, ';')) != NULL) {
						chp = chp1;
					} else {
						chp += strlen(chp);
					}
					break;

				case 'h' :
					i = atoi(++chp);
					if (0 <= i) {
						height = i;
					}
					if ((chp1 = strchr(chp, ';')) != NULL) {
						chp = chp1;
					} else {
						chp += strlen(chp);
					}
					break;

				case 'l' :
					i = atoi(++chp);
					if (i < INITTIMER_MIN) {
						inittimer = INITTIMER_MIN;
					} else if (INITTIMER_MAX < i) {
						inittimer = INITTIMER_MAX;
					} else {
						inittimer = i;
					}
					if ((chp1 = strchr(chp, ';')) != NULL) {
						chp = chp1;
					} else {
						chp += strlen(chp);
					}
					break;

				case 'n' :
					i = atoi(++chp);
					if (i < LITHN_MIN) {
						genn = LITHN_MIN;
					} else if (LITHN_MAX < i) {
						genn = LITHN_MAX;
					} else {
						genn = i;
					}
					if ((chp1 = strchr(chp, ';')) != NULL) {
						chp = chp1;
					} else {
						chp += strlen(chp);
					}
					break;

				case 'm' :
					*stringkind = *(++chp);
					chp++;
					break;

				case 'p' :
					if((chp1 = strchr(++chp, ';')) != NULL) {
						stl = chp1 - chp;
					} else {
						stl = strlen(chp);
					}
					chp1 = chp + stl;
					if (P_NAME_MAX <= stl) {
						stl = P_NAME_MAX - 1;
					}
					strncpy(player, chp, stl);
					player[stl] = NULL;
					chp = chp1;
					break;

				default :
					fprintf(stderr,
"nlith $Revision: 2.2 $ $Date: 88/12/20 02:01:57 $  (c) Taroh Sasaki \n");
					fprintf(stderr,
	"usage : nlith [ PATH ][ -ajstv ][ -dwhnl<NUMBER> ][ -p<PLAYER> ]\n");
					nlexit(1);
				}
			}
		} else {
			if((chp1 = strchr(chp, ';')) != NULL)
				stl = chp1 - chp;
			else
				stl = strlen(chp);
			chp1 = chp + stl;
			if(F_NAME_MAX <= stl) {
				stl = F_NAME_MAX - 1;
			}
			strncpy(filepath, chp, stl);
			filepath[stl] = NULL;
			chp = chp1;
		}
		if (*chp == ';') {
			chp++;
		}
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
initvar1()			/* initialize var before getting options */
{
	wormalcolour = EWH;
	wormcolour   = EVPU;
	wormspcolour = ETU;
	*filepath = NULL;
	getmachine();
}


#ifdef	ANSI
void
#endif	/* ANSI */
initvar2()			/* initialize var after getting options */
{
	int		i;

	if (WELL_BOTTOM <= welldepth && welldepth <= WELL_BOTTOM_MAX) {
		well_bottom = welldepth;
	} else {
		well_bottom = WELL_BOTTOM;
	}
	wellwidth <<= 1;	/* blocks to worms */
	wellx_beg   = (SCR_X - 2 - wellwidth) >> 1;
	wellx_end   = wellx_beg + wellwidth;
	well_top    = well_bottom - welldepth + 1;
	if (welldepth - 1 <= height) {
		height = welldepth - 2;
	}

	if (0 < (i = strlen(filepath))) {
		filepath[i] = PATHDELMT;
		filepath[++i] = NULL;
	}
	if ((! scoreonly) && (! cryptonly)) {
		readstrings();
		readconfig();
		if (wormalcolour == wormcolour || wormalcolour == wormspcolour) {
			wormalcolour = EWH;
			wormcolour   = EVBL;
			wormspcolour = EBL;
		}
	}
	checkwizard();
}


#ifdef	ANSI
void
#endif	/* ANSI */
setvar()			/*** set var before every replay. ***/
{
	looptimer = inittimer;
	moveone		=
	holypoint	=
	evilpoint	=
	blocks		=
	erasedlines	=
	wormlen		= 0;
	score = 0L;
	scorestep = SCORESTEP_INI;
	moving.y[0] = -1;

	setseed();
	getmoonphase();
}


char *
append(chp)
	char	*chp;
{
	int		len;
	char	*oldapptr;

	len = strlen(chp);
	if(strbuf + STR_AREA <= appendptr + len + 1)
		return ((char * )(NULL));

	oldapptr = appendptr;
	strcpy(appendptr, chp);
	*(appendptr + len) = NULL;
	appendptr += (len + 1);

	return (oldapptr);
}


#ifdef	ANSI
void
#endif	/* ANSI */
moonmsg()
{
	if (istraining) {
		return;
	}
	if (pmoon == 0) {
		dispstrings(14);	/* full moon tonight */
	} else if (pmoon == 4) {
		dispstrings(15);	/* new moon tonight */
	}
	flushstrings(1);

	speedup(1, (pmoon * 20 + rnd(20)));		/* 0 .. 99 */
}
