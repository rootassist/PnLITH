/*
 *	"screen.c"
 *
 *		- screen concerned functions
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


#ifdef	ANSI
void
#endif	/* ANSI */
drawscreen()
{
	register	int	i, y;

	clear();
	for (y = well_top; y <= well_bottom; y++) {
		moveto(y, wellx_beg - 1);
		printf("|");
		moveto(y, wellx_end);
		printf("|");
	}
	moveto(well_bottom + 1, wellx_beg - 1);
	printf("+");
	for (i = 0; i < wellwidth; i++) {
		printf("-");
	}
	printf("+");
	drawlogo();
	dispscore();
	if (0 < msgkind[0] &&		/* "strings.nlt" found */
		!istraining) {
		dispwindow();
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
redraw()
{
	norm();
	drawscreen();
	drawgarvages(0);
	if (0 < moving.y[0]) {
		drawlith(&moving);
	}
	if (0 < wormlen) {
		drawworm(wormalcolour);
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
drawlith(draw)
	struct LITH	*draw;
{
	register int	i;

	colour(draw -> attr);
	for (i = 0; i < lithn; i++) {
		wmoveto(draw -> y[i], draw -> x[i]);
		printf("%c%c", draw -> ch1, draw -> ch2);
	}
	norm();
}


#ifdef	ANSI
void
#endif	/* ANSI */
eraselith(draw)
	struct LITH	*draw;
{
	register int	i;

	for (i = 0; i < lithn; i++) {
		wmoveto(draw -> y[i], draw -> x[i]);
		printf("  ");
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
drawlogo()
{
	if (! logotype) {
		return;
	}
	moveto(0, 0);
	colour(ETU);
	printf("####        ####\n");
	printf(" ####        ##\n");
	printf(" ##  ##      ##\n");
	printf(" ##    ##    ##\n");
	printf(" ##      ##  ##\n");
	printf(" ##  ");
	colour(EWH);
	printf("by");
	colour(ETU);
	printf("    ####\n");
	printf("#### ");
	colour(EWH);
	printf("Taroh");
	colour(ETU);
	printf("  ####\n", ESC, EWH, ESC, ETU);
	printf("\n");
	colour(EGR);
	printf(" ###      ####\n");
	printf("  ##       ##\n");
	printf("  ##       ##\n");
	printf("  ##   #   ##\n");
	printf(" #######  ####\n");
	printf("\n");
	printf("#######  ##   ##\n");
	printf("#  #  #   #   #\n");
	printf("   #      #####\n");
	printf("   #      #   #\n");
	printf("  ###    ##   ##\n");
	printf("\n");
	colour(ERE);
	printf(" The block\n");
	printf("       stackker\n");
	colour(0);

	return;
}


#ifdef	ANSI
void
#endif	/* ANSI */
drawgarvages(firstline)
	int		firstline;
{
	register int	x, y;
	int				lastcolour;

	lastcolour = -1;
	for (y = firstline; y < welldepth; y++) {
		wmoveto(y, 0);
		for (x = 0; x < wellwidth; x++) {
			if (map[x][y] != BLANK) {
				if (lastcolour != mapattr[x][y]) {
					colour(mapattr[x][y]);
					lastcolour = mapattr[x][y];
				}
			} else {
				if (lastcolour != -1) {
					norm();
					lastcolour = -1;
				}
			}
			printf("%c", map[x][y]);
		}
	}
	norm();
}


#ifdef	ANSI
void
#endif	/* ANSI */
dispscore()
{
	if (istraining) {
		moveto(14, 62);
		printf("* training mode *");
	}
	moveto(15, 62);
	printf("holy point : %d ", holypoint);
	moveto(16, 62);
	printf("evil point : %d ", evilpoint);
	moveto(18, 62);
	printf("score  : %ld ", score);
	moveto(19, 62);
	printf("blocks : %d", blocks);
	moveto(20, 62);
	printf("lines  : %d", erasedlines);
}


#ifdef	ANSI
void
#endif	/* ANSI */
dispstrings(msgno)
	int		msgno;
{
	if (msgkind[0] == 0 || istraining) {
		return;
	}
	if (msgbufno < MSGBUF_MAX) {
		msgbuf[msgbufno++] = msgno;	
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
flushstrings(fact)
	int				fact;
{
	int				msgno, kind, lines;
	char			dbuf[80];
	register int	i;

	if (msgkind[0] == 0 || istraining) {
		return;
	}
	if (0 < msgbufno && (rnd(fact) == 0 || wizard)) {
		msgno = msgbuf[rnd(msgbufno)];
	} else {
		msgno = 0;
	}
	msgbufno = 0;
	kind = rnd(msgkind[msgno]);

	if (msgno == lastmsgno) {
		return;
	} else {
		lastmsgno = msgno;
	}

	for (lines = 0; msg[msgno][kind][lines] != (char *)(NULL); lines++) {
		moveto(MSGY_BASE + lines, MSGX_BASE);
		for (i = 0; i < MSGX; i++) {
			printf(" ");
		}
		nldecrypt(msg[msgno][kind][lines], dbuf);
		moveto(MSGY_BASE + lines, MSGX_BASE);
		printf("%s", dbuf + 1);	/* skip '>' */
	}
	while (lines < MSGY) {
		moveto(MSGY_BASE + lines, MSGX_BASE);
		for (i = 0; i < MSGX; i++) {
			printf(" ");
		}
		lines++;
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
dispwindow()
{
	register int	i;
	int				n;

	for (n = 0; n < 2; n++) {
		if (n == 0) {
			moveto(MSGY_BASE - 1, MSGX_BASE - 1);
		} else {
			moveto(MSGY_BASE + MSGY, MSGX_BASE - 1);
		}
		printf("+");
		for (i = 0; i < MSGX; i++) {
			printf("-");
		}
		printf("+");

		if (n == 0) {
			for (i = 0; i < MSGY; i++) {
				moveto(MSGY_BASE + i, MSGX_BASE - 1);
				printf("|");
				moveto(MSGY_BASE + i, MSGX_BASE + MSGX);
				printf("|");
			}
		}
	}
	lastmsgno = 0;
}


#ifdef	ANSI
void
#endif	/* ANSI */
control()
{
	clear();
	setraw();
	curoff();
	clear();

	controlled = TRUE;
}


#ifdef	ANSI
void
#endif	/* ANSI */
uncontrol()
{
	if (controlled) {
		curon();
		unsetraw();
	}

	controlled = FALSE;
}


#ifdef	ANSI
void
#endif	/* ANSI */
clear()
{
	printf("%c[2J", ESC);
	moveto(0, 0);
}


#ifdef	ANSI
void
#endif	/* ANSI */
bel()
{
	if (belsw) {
		printf("%c", BEL);
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
colour(colourcode)
{
	if (! coloured) {
		return;
	}
	if (colourcode == 0) {
		printf("%c[m", ESC);
	} else if (40 <= colourcode && colourcode <= 49 &&
			   machine != MA_PC98 && machine != MA_PC98XA &&
			   machine != MA_PC100 && machine != MA_N5200) {
		printf("%c[%d;7m", ESC, colourcode - 10);
	} else {
		printf("%c[%dm", ESC, colourcode);
	}
}
