/*
 *	"pyramid.c"
 *
 *		- calculate date and year
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


/*
int
dow(year, mon, day)
	int		year, mon, day;
{
	return ((int)(abdate(year, mon, day) % 7L));
}
*/


/*
int
dim(year, mon)
	int		year, mon;
{
	long	int	abst;

	abst = abdate(year, mon, 1);
	if (12 < ++mon) {
		mon = 1;
		year++;
	}
	return ((int)(abdate(year, mon, 1) - abst));
}
*/


long int
abdate(year, mon, day)
	int			year, mon, day;
{
	long int	abd;

	if(mon <= 2) {
		mon += 12;
		year--;
	}
	abd =  (long)(year) * 1461L / 4L;		/* x 365.25 */
	abd += (long)(mon + 6) * 153L / 5L;		/* x 30.6 */
	abd += (long)(day + 1);
	return (abd);
}


/*
 *	get phase of the moon to 'pmoon.'
 *
 *	from nethack's phase_of_the_moon(), which is very elegant algorithm.
 *	thanks --- Taroh
 *
 *	0 - 4, with 0 : holy, 4 : evil
 *	moon period: 29.5306 days
 *	year: 365.2422 days
 */
#ifdef	ANSI
void
#endif	/* ANSI */
getmoonphase()
{
	struct tm	*lt;
	int			epact, diy, golden,
				phase;	/* 0 - 7, with 0 : new, 4 : full */

	if (wizard) {
		pmoon = 0;
		return;
	}
	lt = getdt();
	diy = lt->tm_yday;
	golden = (lt->tm_year % 19) + 1;
	epact = (11 * golden + 18) % 30;
	if ((epact == 25 && golden > 11) || epact == 24)
		epact++;

	phase = (((((diy + epact) * 6) + 11) % 177) / 22) & 7;
	phase -= 4;
	pmoon = abs(phase);
}
