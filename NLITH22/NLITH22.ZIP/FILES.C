/*
 *	"files.c"
 *
 *		- file reading and writing functions
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


int
getintfld(chp)
	char	**chp;
{
	int		i;

	(*chp)++;
	if((!isnumber(**chp))) {
		return (-1);
	}
	i = atoi(*chp);
	if ((*chp = strchr(*chp, ' ')) == NULL) {
		return (-1);
	}
	return (i);
}


#ifdef	ANSI
void
#endif	/* ANSI */
panic()
{
	register int	i;
	int				curx, cury, conx, cony;
	char			fbuf[BUFLEN], *chp;
	FILE			*fd;

	clear();
	pictureoff();
	fd = scanxopen("panic");
	if (fd == NULL || fgets(fbuf, BUFLEN, fd) == NULL) {
		printf(PROMPT_STR);
		curx = PROMPT_X;
		cury = 0;
	} else {
		cury = atoi(fbuf);
		chp = jmpbr(jmpch(fbuf));
		curx = atoi(chp);
		chp = jmpbr(jmpch(chp));
		cony = atoi(chp);
		chp = jmpbr(jmpch(chp));
		conx = atoi(chp);
		if (conx < 1 || cony < 1) {		/* no console lines specified. */
			i = 1;
			moveto(0, 0);
			printf("%s", fbuf);
			conx = 80;
			cony = 99;		/* I've never seen a console over 99 lines. */
		} else {
			i = 0;
		}
		for ( ; i < cony && fgets(fbuf, BUFLEN, fd) != NULL; i++) {
			moveto(i, 0);
			if ((chp = strchr(fbuf, NL)) != NULL) {
				*chp = NULL;
			}
			printf("%s", fbuf);
		}
		fclose(fd);
		if (conx < curx) {
			curx = conx;
		}
		if (cony < cury) {
			curx = 0;
			cury = cony;
		}
	}
	curon();
	panicworks(cury, curx, cony, conx);
	curoff();
	pictureon();
	redraw();
}


#ifdef	ANSI
void
#endif	/* ANSI */
panicworks(cury, curx, cony, conx)
	int		cury, curx, cony, conx;
{
	int		newx, newy;
	char	ch;

	newx = curx;
	newy = cury;
	moveto(cury, curx);
	while(TRUE) {
		ch = Getchar();
		switch (keyalias(ch)) {

		case FN_PANIC :
			return;

		case FN_DROP :
			newx = curx;
			newy = cury + 1;
			break;

		case FN_LEFT :
			newx = curx - 1;
			newy = cury;
			break;

		case FN_ROTA :
			newx = 0;
			newy = cury + 1;
			break;

		case FN_RIGHT :
			newx = curx + 1;
			newy = cury;
			break;

		case FN_PRAY :
			newx = curx;
			newy = cury - 1;
			break;
		}
		if (newy < 0) {
			cury = 0;
		} else if (cony - 1 < newy) {
			cury = cony - 1;
		} else {
			cury = newy;
		}
		if (newx < 0) {
			curx = 0;
		} else if (conx - 1 < newx) {
			curx = conx - 1;
		} else {
			curx = newx;
		}
		moveto(cury, curx);
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
readstrings()
{
	int			msgno, kind, lines;
	static char	fbuf[BUFLEN], fbuf2[BUFLEN];
	char		stringfile[F_NAME_MAX];
	BOOLEAN		ilf;
	FILE		*fd;

	msgno =
	kind =
	lines = 0;
	msgkind[0] = 0;
	ilf = FALSE;

	getgamedir(stringfile, filepath);
	strcat(stringfile, "strings");
	strcat(stringfile, stringkind);
	strcat(stringfile, ".nlt");
	if ((fd = fbopen(stringfile, "r")) == NULL) {
		getgamedir(stringfile, filepath);
		strcat(stringfile, "strings.nlt");
		if ((fd = fbopen(stringfile, "r")) == NULL) {
			return;
		}
	}
	if ((strbuf = appendptr = malloc(STR_AREA)) == NULL) {
		fatal("memory too few");
		return;
	}

	fgetc(fd);
	while ((nlfgets(fbuf, 80, fd)) != EOF) {
		nldecrypt(fbuf, fbuf2);
		if (*fbuf2 == '#') {
			continue;
		} else if (*fbuf2 == ',') {
			msg[msgno][kind][lines] = (char *)(NULL);
			kind++;
			lines = 0;
		} else if (*fbuf2 == '-') {
			msgkind[msgno] = ++kind;
			msgno++;
			kind =
			lines = 0;
		} else if (*fbuf2 == '>') {
			msg[msgno][kind][lines] = append(fbuf);
			lines++;
		} else {
			ilf = TRUE;
			break;
		}
		if (KIND_MAX <= kind) {
			ilf = TRUE;
			break;
		}
		if (MSG_MAX <= msgno) {
			break;
		}
	}
	fclose(fd);
	if (ilf || msgno < MSG_MAX) {
		msgkind[0] = 0;
		fprintf(stderr, "* \"%s\" is illegal.\n", stringfile);
		fprintf(stderr, "  Use right stringfile.\n");
		warn = TRUE;
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
readconfig()
{
	register int	i;
	int				colno, stl, alis;
	char			fbuf[BUFLEN],
					name[4], ch[3], col[5],
					*chp, *chp1;
	FILE			*fd;

	if ((fd = scanxopen("config")) == NULL) {
		return;
	}
	while ((fgets(fbuf, BUFLEN, fd)) != NULL) {
		if ((chp = strchr(fbuf, NL)) != NULL) {
			*chp = NULL;
		}
		if (*fbuf == '#') {
			continue;
		}
		chp = fbuf;
		if ((chp1 = strchr(chp, '=')) == NULL) {
			chp = jmpbr(chp);
			if (*chp == NULL) {
				continue;
			}
			if (strnlcmp(chp, "alias", 5) == 0) {
				chp = jmpbr(chp + 5);
				if (*chp == NULL) {
					continue;
				}
				if (*chp == '^') {
					if (*(++chp) == NULL) {
						continue;
					}
					alis = (int)(Toupper(*chp)) - 0x40;
				} else if (*chp == '\\') {
					chp++;
					if (*chp == NULL) {
						continue;
					} else if (*chp == '\\') {
						alis = (int)('\\');
					} else if (*chp == 'x' || *chp == 'X') {
						alis = atox(++chp);
					} else {
						alis = atoi(chp);
					}
				} else {
					alis = (int)(*chp);
				}
				chp = jmpch(chp);
				if ((stl = strfld(&chp)) == 0) {
					continue;
				}
				for (i = 0; fn_name[i][0] != NULL; i++) {
					if (strnlcmp(chp, fn_name[i], FNLEN) == 0) {
						aliasmap[alis] = i;
						break;
					}
				}
			} else if (strnlcmp(chp, "beep", 4) == 0) {
				belsw = getsw(chp + 4);
			} else if (strnlcmp(chp, "logo", 4) == 0) {
				logotype = getsw(chp + 4);
			} else if (strnlcmp(chp, "colour", 6) == 0) {
				coloured = getsw(chp + 6);
			} else if (strnlcmp(chp, "jump", 4) == 0) {
				isjump = getsw(chp + 4);
			} else if (strnlcmp(chp, "ansi", 4) == 0) {
				ansiwrite = getsw(chp + 4); 
			}
			continue;
		}
		*chp1 = NULL;
		if (3 < (stl = strfld(&chp))) {
			continue;
		}
		strncpy(name, chp, stl);
		name[stl] = NULL;
		chp1++;
		if ((chp = strchr(chp1, ',')) != NULL) {
			*(chp++) = NULL;
			if (2 < (stl = strfld(&chp))) {
				continue;
			}
			strncpy(ch, chp, stl);
			ch[stl] = NULL;
		} else {
			*ch = NULL;
		}
		if (4 < (stl = strfld(&chp1))) {
			continue;
		}
		strncpy(col, chp1, stl);
		col[stl] = NULL;

		if (*col == NULL) {
			colno = -1;
		} else if ((colno = atoi(col)) == 0) {
			colno = -1;
			strlwr(col);
			for (i = 0; i < MAXCOLREF; i++) {
				if (strcmp(col, colref[i].name) == 0) {
					colno = colref[i].colno;
					break;
				}
			}
		}
		strlwr(name);
		for (i = 0; i < MAXINIINFO; i++) {
			if (strcmp(name, iniinfo[i].name) == 0) {
				if (colno != -1) {
					iniinfo[i].shape.attr = colno;
				}
				if (ch[0] != NULL) {
					iniinfo[i].shape.ch1 = ch[0];
					iniinfo[i].shape.ch2 = ch[1];
				}
				break;
			}
		}
		if (i == MAXINIINFO) {		/* another name */
			if (strcmp(name, "wal") == 0) {
				if (colno != -1) {
					wormalcolour = colno;
				}
				continue;
			}
			if (strcmp(name, "whd") == 0) {
				if (colno != -1) {
					wormcolour = colno;
				}
				if (ch[0] != NULL) {
					wormhead = ch[0];
				}
				continue;
			}
			if (strcmp(name, "wbd") == 0) {
				if (colno != -1) {
					wormcolour = colno;
				}
				if (ch[0] != NULL) {
					wormbody = ch[0];
				}
				continue;
			}
			if (strcmp(name, "wsp") == 0) {
				if (colno != -1) {
					wormspcolour = colno;
				}
				if (ch[0] != NULL) {
					wormspilit = ch[0];
				}
				continue;
			}
		}
	}
	fclose(fd);
}


int
strfld(chp1)
/*
 *	strings field.
 *	return value is length of field, and pointer points the beggining of field.
 */
	register char    **chp1;
{
	register char    *chp2;

	*chp1 = jmpbr(*chp1);
	if(**chp1 == NULL)
		return(NULL);
	chp2 = jmpch(*chp1);

	return (chp2 - *chp1);
}


char *
jmpbr(chp)
/*
 *	jump strings blank.
 */
	register char    *chp;
{
	while(*chp == TAB || *chp == BLANK) {
		chp++;
	}
	return (chp);
}


char *
jmpch(chp)
/*
 *	skip strings field.
 */
	register char    *chp;
{
	while(*chp != TAB && *chp != BLANK &&
		  *chp != EOL && *chp != NULL) {
		chp++;
    }
	return (chp);
}


int
atox(chp)
	char	*chp;
{
	int		i;

	i = 0;
	strlwr(chp);
	while (TRUE) {
		if ('0' <= *chp && *chp <= '9') {
			i <<= 4;
			i += ((int)(*chp) - '0');
		} else if ('a' <= *chp && *chp <= 'f') {
			i <<= 4;
			i += ((int)(*chp) - 'a' + 10);
		} else {
			break;
		}
		chp++;
	}
	return (i);
}


int
strnlcmp(chp1, chp2, len)
	char	*chp1, *chp2;
	int		len;
{
	for ( ; *chp1 != NULL && *chp2 != NULL && 0 < len; chp1++, chp2++, len--) {
		if (Tolower(*chp1) != *chp2) {
			return (1);
		}
	}
	return (0);
}


FILE *
scanxopen(basename)
	char	*basename;
{
	char	namebuf[F_NAME_MAX];
	FILE	*fd;

	strcpy(namebuf, filepath);
	strcat(namebuf, basename);
	strcat(namebuf, stringkind);
	strcat(namebuf, ".nlt");
	if ((fd = fopen(namebuf, "r")) != NULL) {
		return (fd);
	}
	strcpy(namebuf, filepath);
	strcat(namebuf, basename);
	strcat(namebuf, ".nlt");
	if ((fd = fopen(namebuf, "r")) != NULL) {
		return (fd);
	}
	getgamedir(namebuf, filepath);
	strcat(namebuf, basename);
	strcat(namebuf, stringkind);
	strcat(namebuf, ".nlt");
	if ((fd = fopen(namebuf, "r")) != NULL) {
		return (fd);
	}
	getgamedir(namebuf, filepath);
	strcat(namebuf, basename);
	strcat(namebuf, ".nlt");
	if ((fd = fopen(namebuf, "r")) != NULL) {
		return (fd);
	}
	return (NULL);
}


BOOLEAN
getsw(chp)
	char	*chp;
{
	chp = jmpbr(chp);
	if (*chp == NULL) {
		return (TRUE);
	}
	if (Tolower(*chp) == 'n') {
		return (FALSE);
	} else {
		return (TRUE);
	}
}
