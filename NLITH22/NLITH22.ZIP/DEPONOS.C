/*
 *	"deponos.c"
 *
 *		- match ( mainly ) OS dependent modules
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"

#ifdef		MSDOS
#	include	<fcntl.h>
#	include	<io.h>
#	include	<process.h>
# ifndef	X68K
#	include <dos.h>
#	include	<signal.h>
# endif		/* NOT X68K */
# ifdef		X68K
#		include <doslib.h>
# endif		/* X68K */
#endif
#ifndef	MSDOS
#	include	<signal.h>
#	include	<pwd.h>
#endif

#ifndef	sigmask
#	define	sigmask(signo)	(1 << (signo - 1))
#endif


/*
 *	setraw() & unsetraw() -
 *	set & unset console (... you use windows? OK!) to RAW mode,
 *		stdin  : don't care buffering and interrupts,
 *		stdout : don't care buffering.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
setraw()
{
#ifdef		MSDOS
# ifndef	X68K
	union REGS regs;

	regs.h.ah=0x44;
	regs.h.al=0x01;
	regs.x.bx=0x0001;

	regs.h.dh=0x00;
	regs.h.dl=0xf3;
	
	intdos(&regs, &regs);
# endif		/* NOT X68K */
# ifdef		X68K
	KFLUSHIO(0xff);
# endif		/* X68K */
#endif		/* MSDOS */

#ifndef		MSDOS
# ifndef	SYSV
		struct	sgttyb	tmptty;

		ioctl(0, TIOCGETP, &savetty);
		ioctl(0, TIOCGETP, &tmptty);
		tmptty.sg_flags &= ~RAW;
		tmptty.sg_flags |= CBREAK;
		tmptty.sg_flags &= ~ECHO;
		tmptty.sg_flags |= CRMOD;
		ioctl(0, TIOCSETP, &tmptty);
# endif		/* NOT SYSV */
# ifdef		SYSV
		struct	termio	tmptty;

		ioctl(0, TCGETAW, &savetty);
		ioctl(0, TCGETA, &tmptty);
		tmptty.c_iflag  &= ~INLCR;
		tmptty.c_iflag  &= ~ICRNL;
		tmptty.c_iflag  &= ~ONLCR;
		tmptty.c_iflag  &= ~IUCLC;
		tmptty.c_iflag  &= ~BRKINT;
		tmptty.c_oflag  |= ONLCR;
		tmptty.c_oflag  &= ~OUCLC;
		tmptty.c_lflag  &= ~ECHO;
		tmptty.c_lflag  &= ~ISIG;
		tmptty.c_lflag  &= ~ICANON;
		tmptty.c_cc[4]  = 1;
	/*	tmptty.c_cc[5]  = 0;	*/
		ioctl(0, TCSETAW, &tmptty);
# endif		/* SYSV */
#endif		/* NOT MSDOS */
}


#ifdef	ANSI
void
#endif	/* ANSI */
unsetraw()
{
#ifdef		MSDOS
# ifndef	X68K
	union REGS regs;

	regs.h.ah=0x44;
	regs.h.al=0x01;
	regs.x.bx=0x0001;

	regs.h.dh=0x00;
	regs.h.dl=0xD3;
	
	intdos(&regs, &regs);
# endif		/* NOT X68K */
# ifdef		X68K
	KFLUSHIO(0xff);
# endif		/* X68K */
#endif		/* MSDOS */

#ifndef		MSDOS
# ifndef	SYSV
		ioctl(0, TIOCSETP, &savetty);
# endif		/* NOT SYSV */
# ifdef		SYSV
		ioctl(0, TCSETAW, &savetty);
# endif		/* SYSV */
#endif		/* NOT MSDOS */
}


/*
 *	whoareyou() -
 *	ask player's name,
 *	if	cannot get playername by -pXXX (MSD*S),
 *		cannot get playername by /etc/passwd, or id is for GUEST(U*IX).
 */
#ifdef	ANSI
void
#endif	/* ANSI */
whoareyou()
{
	int		stl;
	char	buf[BUFLEN];

#ifndef	MSDOS
	struct passwd	*pwent;

	if ((pwent = getpwuid(getuid())) != NULL) {
		if (P_NAME_MAX <= (stl = strlen(pwent -> pw_name))) {
			stl = P_NAME_MAX - 1;
		}
		strncpy(player, pwent -> pw_name, stl);
		player[stl] = NULL;

		if (strcmp(player, GUESTID) == 0) {
			*player = NULL;
		}
	} else {
		fprintf(stderr, "* Cannot get username.\n");
		warn = TRUE;
	}
#endif	/* NOT MSDOS */

	if (*player == NULL) {
		while(TRUE) {
			fprintf(stderr, "Who are you : ");
			if ((fgets(buf, BUFLEN, stdin)) == NULL) {
				continue;
			}
			if (0 < (stl = strlen(buf) - 1)) {
								/*** last 1 char will be LF. ***/
				if (P_NAME_MAX <= stl) {
					stl = P_NAME_MAX - 1;
				}
				break;
			}
		}
		strncpy(player, buf, stl);
		player[stl] = NULL;
	}

	for (stl = 0; player[stl] != NULL; stl++) {
		if (player[stl] == ' ') {
			player[stl] = '_';
		}
	}
}


/*
 *	fbopen() - open file and set filemode to binary.
 *	ignore ^Z as EOF when reading crypted files on MS*OS,
 *	stop mapping CR to CR LF (LF to CR LF) on U*IX.
 */
FILE	*
fbopen(path, mode)
	char	*path, *mode;
{
#ifdef		MSDOS
# ifndef	X68K
	FILE	*fd;

	if ((fd = fopen(path, mode)) != NULL) {
		setmode(fileno(fd), O_BINARY);
		return (fd);
	} else {
		return (NULL);
	}
# endif		/* NOT X68K */
# ifdef		X68K
	char	modeb[3];

	strcpy(modeb, mode);
	strcat(modeb, "b");
	
	return (fopen(path, modeb));
# endif		/* X68K */
#endif		/* MSDOS */

#ifndef	MSDOS
	FILE	*fd;

# ifndef	SYSV
	struct	sgttyb	tmptty;

	if ((fd = fopen(path, mode)) != NULL) {
		ioctl(fileno(fd), TIOCGETP, &tmptty);
		tmptty.sg_flags &= ~CRMOD;
		ioctl(fileno(fd), TIOCSETP, &tmptty);
		return (fd);
	} else {
		return (NULL);
	}
# endif	/* NOT SYSV */
# ifdef	SYSV
	struct	termio	tmptty;

	if ((fd = fopen(path, mode)) != NULL) {
		ioctl(fileno(fd), TCGETA, &tmptty);
		tmptty.c_iflag  &= ~INLCR;
		tmptty.c_iflag  &= ~ICRNL;
		ioctl(fileno(fd), TCSETA, &tmptty);
		return (fd);
	} else {
		return (NULL);
	}
# endif	/* NOT SYSV */
#endif	/* NOT MSDOS */
}


/*
 *	getgamedir() - get scorefile's & strings' directory.
 *	usually personal setting (get by option or environment) on MS*OS,
 *	"/usr/games/lib" on *NIX (described in "makefile").
 */
#ifdef	ANSI
void
#endif	/* ANSI */
getgamedir(scorefile, fpath)
	char	*scorefile, *fpath;
{
#ifdef	MSDOS
	strcpy(scorefile, fpath);
#endif	/* MSDOS */

#ifndef	MSDOS		/* "filepath" ignored */
	fpath = fpath;
	strcpy(scorefile, GAMEDIR);
#endif	/* MSDOS */
}


struct tm *
getdt()
{
#ifdef		MSDOS	/* tm_yday must be calculated */
	static struct tm	localtm;

# ifndef	X68K
	union REGS			regs;

	regs.h.ah = 0x2c;
	intdos(&regs, &regs);
	localtm.tm_hour = regs.h.ch;
	localtm.tm_min  = regs.h.cl;
	localtm.tm_sec  = regs.h.dh;

	regs.h.ah = 0x2a;
	intdos(&regs, &regs);
	localtm.tm_year = regs.x.cx - 1900;
	localtm.tm_mon  = regs.h.dh - 1;
	localtm.tm_mday = regs.h.dl;
	localtm.tm_wday = regs.h.al;
# endif		/* NOT X68K */
# ifdef 	X68K
	int			time,date;

	time = GETTIME();
	localtm.tm_hour	= time >> 11;
	localtm.tm_min	= (time >> 5) & 0x3f;
	localtm.tm_sec	= (time & 0x1f)*2;

	date = GETDATE();
	localtm.tm_year	= 80 + ((date >> 9) & 0x7f);
	localtm.tm_mon	= ((date >> 5) & 0x0f)-1;
	localtm.tm_mday = date & 0x1f;
	localtm.tm_wday = date >> 18;
# endif		/* X68K */

	localtm.tm_yday = (int)
		(abdate(localtm.tm_year, localtm.tm_mon, localtm.tm_mday) -
		 abdate(localtm.tm_year, 0,              1)
		);

	return (&localtm);
#endif		/* MSDOS */

#ifndef MSDOS
	long int	ltime;

	time(&ltime);
	return (localtime(&ltime));
#endif	/* NOT MSDOS */
}


/*
 *	setsig() - set signal traps.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
setsig()
{
#ifdef		MSDOS
# ifdef		SIGABRT		/* for TURBO-C */
	ssignal(SIGABRT, SIG_IGN);
# endif		/* SIGABRT */
# ifndef	SIGABRT		/* for MS-C */
	signal(SIGINT, SIG_IGN);
# endif		/* NOT SIGABRT */
#endif		/* MSDOS */

#ifndef	MSDOS

	register int	i;

	for (i = 0; i < NSIG; i++) {
		signal(i, SIG_IGN);
	}

	signal(SIGHUP,  hungup);
	signal(SIGSTOP, SIG_DFL);

# ifndef	SYSV
#  ifndef	BSD41
	signal(SIGTSTP, suspend);
#  endif	/* NOT BSD41 */
# endif	/* NOT SYSV */

#endif	/* NOT MSDOS */
}
  
  
/*
 *	suspend() - trap SIGTSTP and service suspend by ^Z.
 *	(BSD *NIX, depend on sigvec, only available on BSD 4.2 later)
 */
#ifndef	MSDOS
# ifndef	SYSV
#  ifndef	BSD41
#   ifdef	ANSI
void
#			endif	/* ANSI */
suspend()
{

	int		oldmask;

	/*--- SIGALRM, SIGTSTP are masked ---*/
	unsetraw();
  
	/* prevent us from signaling by ALARM.
	 * Needless to say, we are safe from SIGTSTP.
	 */
	oldmask = sigblock(sigmask(SIGALRM));
	moveto(23, 0);		/* move cursor to bottom of line */
	fflush(stdout);
	kill(0, SIGSTOP);	/* kill MYSELF. SIGSTOP still have default action */
  
	/*--- sleeping (^Z^Z^Zzzz...) ---*/
  
	setraw();
	redraw();

	sigsetmask(oldmask);    /* restore the masks */
}
#  endif	/* NOT BSD41 */
# endif		/* NOT SYSV */
#endif		/* NOT MSDOS */


/*
 *	hungup() - trap SIGHUP and service hungup.
 */
#ifndef	MSDOS
# ifdef	ANSI
void
# endif	/* ANSI */
hungup()
{
	addbonus();
	if (istraining) {
		precone(0, PRA_REC);
	} else {
		precone(CURRENT_DAYS, PRA_REC);
		precone(0           , PRA_REC);
	}
	nlexit(1);

/*--- needless to reset handler, because never comes the same signal ---*/

}
#endif	/* NOT MSDOS */


#ifdef	ANSI
void
#endif	/* ANSI */
shellinvoke()
{
	char	*chp;

	uncontrol();
	clear();
	printf("( to exit shell, type \"exit\". )\n");

#ifdef	MSDOS
	if ((chp = getenv("COMSPEC")) == (char *)(NULL)) {
		spawnlp(P_WAIT, "command", "command", NULL);
	} else {
		spawnl(P_WAIT, chp, chp, NULL);
	}
#endif	/* MSDOS */

#ifndef	MSDOS
	if ((chp = getenv("SHELL")) == (char *)(NULL)) {
		chp = "/bin/sh";
	}
	system(chp);
#endif	/* NOT MSDOS */

	control();
	redraw();
}
