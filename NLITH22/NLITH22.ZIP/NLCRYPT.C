/*
 *	"nlcrypt.c"
 *
 *		- functions concerned secret file
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


#ifdef	ANSI
void
#endif	/* ANSI */
nldecrypt(schp, dchp)
	char	*schp, *dchp;
{
	char		*chp;

	for (chp = dchp; *schp != NULL; schp++, chp++) {
		if ((0xff & *schp) == 0xff) {
			if ((0xff & *(++schp)) == 0xff) {
				*chp = (char)(0xff);
			} else {
				*chp = (char)(*schp & 0x7f);
			}
		} else {
			*chp = *schp;
		}
	}
	for ( ; dchp < chp; dchp++) {
		*dchp = (*dchp ^ *(dchp + 1));
	}
	*(dchp - 1) = (char)(NULL);
}


#ifdef	ANSI
void
#endif	/* ANSI */
nlencrypt(schp, dchp)
	char	*schp, *dchp;

{
	int		ch, lastch;

	*(dchp++) =
	lastch    = (char)(rnd(0xe0) + 0x20);
	for ( ; *schp != NULL; schp++, dchp++) {
		ch = lastch ^ (int)(*schp);
		if ((0xff & ch) < 0x20) {
			*(dchp++) = (char)(0xff);
			*dchp = (char)(ch | 0x80);
		} else if ((0xff & ch) == 0xff) {
			*(dchp++) = (char)(0xff);
			*dchp = (char)(0xff);
		} else {
			*dchp = (char)(ch);
		}
		lastch = ch;
	}
	*dchp = NULL;
}


/*
 *	nlfgets() -
 *	get crypted strings routine.
 *
 *	read crypted string for 1 "crypted" line.
 *	part of string over "len" is discarded.
 *	if internal error occured, EOF is returned as error.
 *	fd must be opend with binary mode.
 */
int
nlfgets(chp, len, fd)
	char	*chp;
	int		len;
	FILE	*fd;
{
	int				readlen, ch, linelen, csum;
	register int	i;

	if ((linelen = fgetc(fd)) == EOF) {	/* end of file comes */
		return (EOF);
	}
	csum =
	readlen = 0;
	for (i = 0 ; i < linelen; i++) {
		if ((ch = fgetc(fd)) == EOF) {
			return (EOF);
		}
		csum += ch;
		if (0 < len) {					/* already buffer is full */
			*chp = (char)(ch);
			if (0 < (--len)) {			/* buffer is not full */
				readlen++;
				chp++;
			}
		}
	}
	if ((ch = fgetc(fd)) == EOF) {		/* no checksum */
		return (EOF);
	} else {
		if ((csum & 0xff) == (ch & 0xff)) {
			*chp = NULL;
			return (readlen);
		} else {
			return (EOF);				/* checksum failed */
		}
	}
}


/*
 *	nlfputs() -
 *	get crypted strings routine.
 *
 *	write crypted string for 1 "crypted" line.
 *	fd must be opened with binary mode.
 */
int
nlfputs(chp, fd)
	char	*chp;
	FILE	*fd;
{
	int				linelen, csum;
	register int	i;

	linelen = strlen(chp);
	if (0xff < linelen) {
		return (NULL);
	}
	fprintf(fd, "%c", linelen);
	csum = 0;
	for (i = 0 ; i < linelen; i++, chp++) {
		fprintf(fd, "%c", *chp);
		csum += *chp;
	}
	fprintf(fd, "%c", csum);
	return (linelen);
}


/*
 *	checkwizard() - check if wizard or not.
 *
 *	CAUTION : anyone who could know wizard passwd must not leak
 *	          the secret. remember, it is for debugger.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
checkwizard()
{
	char	schp[11], dchp[9];

	strcpy(schp, "\141\030\155\377\200\151\012\142\003\155\000");
	nldecrypt(schp, dchp);
	if (strcmp(dchp, player) == 0) {
		wizard = TRUE;
		*player = NULL;
	}
}


/*
 *	cryptstrings
 *
 *	- encript routine of "stringsX.src" -> "stringsX.nlt", always on
 *	  current directory.
 *	  no check is done on source file.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
cryptstrings()
{
	char	srcfilename[F_NAME_MAX], destfilename[F_NAME_MAX],
			srcbuf[BUFLEN], destbuf[BUFLEN],
			*chp;
	FILE	*srcfd, *destfd;

	if (! wizard && ! scoreonly) {
		fatal("nonwizard tried to create something");
	}
	if (scoreonly) {
		strcpy(srcfilename, "record.src");
		strcpy(destfilename, "record.nlt");
	} else {
		strcpy(srcfilename, "strings");
		strcat(srcfilename, stringkind);
		strcat(srcfilename, ".src");
		strcpy(destfilename, "strings");
		strcat(destfilename, stringkind);
		strcat(destfilename, ".nlt");
	}
	if ((srcfd = fopen(srcfilename, "r")) == NULL) {
		fatal("cannot open source file");
	}
	if ((destfd = fbopen(destfilename, "w")) == NULL) {
		fatal("cannot open destination file");
	}
	fprintf(destfd, "%c", 0x1a);
	while (fgets(srcbuf, BUFLEN, srcfd) != NULL) {
		if ((chp = strchr(srcbuf, NL)) != NULL) {
			*chp = NULL;
		}
		nlencrypt(srcbuf, destbuf);
		nlfputs(destbuf, destfd);
	}
}
