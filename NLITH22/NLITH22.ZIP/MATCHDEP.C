/*
 *	"matchdep.c"
 *
 *		- match ( mainly ) machine ( or language ) dependent modules
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"

#ifdef	MSDOS
# ifndef X68K
#		include <dos.h>
# endif
# ifdef X68K
#		include <doslib.h>
# endif
#	include	<fcntl.h>
#	include	<io.h>
#	include	<process.h>
#endif
#ifndef	MSDOS
#	include	<signal.h>
#	include	<pwd.h>
#endif

/*
 *	setseed() - randomize random function's seed.
 *
 *			common between UN*X & M*DOS, but getting the seed
 *		- actually time constant - affects object size and
 *		long value and ... on MuchSmaller-DOS.  (^_^)
 */
#ifdef	ANSI
void
#endif	/* ANSI */
setseed()
{
#ifdef		MSDOS
# ifndef	X68K
	union REGS regs;

	regs.h.ah=0x2c;
	intdos(&regs, &regs);
	srand((unsigned)((regs.h.ch ^ regs.h.cl) << 8) + regs.h.dh);
# endif		/* NOT X68K */
# ifdef	X68K
	int 	tp;

	time(&tp);
	srand(tp);
# endif		/* X68K */
#endif		/* MSDOS */
#ifndef MSDOS
	long	ltime;

	time(&ltime);
	srandom((int)(ltime % 0x8000L));
#endif
}


/*
 *	movelithone() & (scankeyboard() | settimeout()) -
 *	some functions depend on interrupt handling.
 *
 *		on M*DOS : loop for time-constant and scan input.
 *			(pararrel timer not supported, but keyscan available)
 *
 *		on U*IX  : set timer-interrupt and input from keyboard.
 *			(pararrel timer supported, but keyscan looping takes much
 *			 CPU power)
 */


/*
 *	M*DOS only function : scan keyboard, move block (if available).
 */
#ifdef	MSDOS
# ifdef	ANSI
void
# endif	/* ANSI */
movelithone()
{
	int		t;
	char	ch;

	home();
	for (t = 0; t < looptimer; t++) {
		if ((ch = scankeyboard()) != NULL) {
			docmd(ch);
			home();
		}
	}
}
#endif	/* MSDOS */

/*
	^
	|	same function ...
	v
 */

/*
 *	UN*X only function : input from keyboard and move block (if available).
 */
#ifndef	MSDOS
# ifdef	ANSI
void
# endif	/* ANSI */
movelithone()
{
	char	buf;
# ifdef		ITIMER
	struct itimerval	itime;
# endif		/* NOT ITIMER */

	home();
	fflush(stdout);
	if (setjmp(jmpenv) != 0) {
		goto  its_timeout;
	}
	signal(SIGALRM, settimeout);

# ifndef	ITIMER
	alarm((unsigned)(looptimer));
# endif		/* NOT ITIMER */
# ifdef		ITIMER
	itime.it_value.tv_sec  =  looptimer / 1000;
	itime.it_value.tv_usec = (looptimer % 1000) * 1000;
	itime.it_interval = itime.it_value;
	setitimer(ITIMER_REAL, &itime, (struct itimerval *)(NULL));
# endif		/* ITIMER */

	alrmsem = ALRM_OK;
	while (TRUE) {
		if(read(0, &buf, (unsigned)(1)) == -1) {
			break;
		}
		alrmsem = ALRM_SUSP;
		docmd(buf);
		dosuspended();
		home();
		fflush(stdout);
	}

its_timeout :
	alrmsem = ALRM_IGN;
	signal(SIGALRM, SIG_IGN);
}


/*
 *	dosuspended() -
 *	send myself an alarmsignal which is suspended while doing command
 *	on U*IX.
 */
# ifdef	ANSI
void
# endif	/* ANSI */
dosuspended()
{
	if (alrmsem == ALRM_SUSON) {
		alrmsem = ALRM_OK;
		kill(0, SIGALRM);
	} else {
		alrmsem = ALRM_OK;
	}
}
#endif	/* NOT MSDOS */




#ifdef	MSDOS
/*
 *	M*DOS only function : scan keyboard, not block if no input.
 */
char
scankeyboard()
{
# ifndef 	X68K
	union REGS regs;

	regs.h.ah = 0x06;
	regs.h.dl = 0xff;

	intdos(&regs, &regs);

	return (regs.h.al);
# endif		/* NOT X68K */
# ifdef		X68K
	char ch;
	ch = (int)INPOUT(0xff);
	return (ch);
# endif		/* X68K */
}
#endif	/* MSDOS */


/*
 *	UN*X only function : timer interrupt handler.
 */
#ifndef	MSDOS
# ifdef	ANSI
void
# endif	/* ANSI */
settimeout(signo)
	int		signo;
{
	signo = signo;

/*
 *		never IGNore SIG_ALRM in this routine.
 *	if it is ignored when alrmsem is ALRM_SUSP, suspend alarm will
 *	never done when this routine is called again by dosusp() lately.
 *		in fact, unexpected SIG_ALRM would never reach.
 */

	if (alrmsem == ALRM_OK) {
		longjmp(jmpenv, 1);
/*
 *		bsd 4.2 or 4.3, read() is not interrupted by signal,
 *	that we must leave from read() by using longjmp.
 *	any other versions, we can getaway from systemcall anyway.
 */

	} else if (alrmsem == ALRM_SUSP) {
		alrmsem = ALRM_SUSON;
	}
	return;
}
#endif	/* NOT MSDOS */


/*
 *	speedup() - speedup function.
 *	needless on *NIX, which timer interrupt never occures once a second.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
speedup(fact, value)	/* depend on timer value */
{
#ifdef	MSDOS
	if (rnd(fact) == 0) {
		if (value < looptimer) {
			looptimer -= value;
		}
	}
#endif	/* MSDOS */
#ifdef	ITIMER
	register int	j;

	if (rnd(fact) == 0) {
		j = looptimer - value;
		if (TIMER_MIN <= j) {
			looptimer = j;
		}
	}
#endif	/* ITIMER */
}


/*
 *	strlwr() - MSDO*' local function, which uncaptalize whole string.
 */
#ifndef	MSDOS
# ifdef	ANSI
void
# endif	/* ANSI */
strlwr(chp)
	char	*chp;
{
	for ( ; *chp != NULL; chp++) {
		*chp = Tolower(*chp);
	}
}
#endif	/* NOT MSDOS */


/*
 *	getmachine() - return machine code (MSDO*).
 *
 *	we can move cursor faster to operate DOS directly.
 *	other OS is not affected, returning (-1).
 */
#ifdef	ANSI
void
#endif		/* ANSI */
getmachine()
{
#ifndef	MSDOS
	machine = MA_NOMS;
	return;
#endif		/* NOT MSDOS */
#ifdef		MSDOS
# ifdef		X68K
	machine = MA_MSOTHER;
# endif		/* X68K */
# ifndef	X68K
/*
 *	from TURBO-C's "MK_FP" ("dos.h"),
 *	which is not defined in MS-C.
 */
#	define MAKE_FP(seg, ofs)	((void far *) \
			   (((unsigned long)(seg) << 16) | (unsigned)(ofs)))

	char far	*fchp;

	fchp = MAKE_FP(0xffff, 0x0003);
	if (((0xff & *fchp) == 0x80 && (0xff & *(fchp + 1)) == 0xfd)) {
		machine = MA_PC98;
	} else if ((0xff & *fchp) == 0x00 && (0xff & *(fchp + 1)) == 0xf8) {
		machine = MA_PC98XA;
	} else if ((0xff & *fchp) == 0x00 && (0xff & *(fchp + 1)) == 0xf0) {
		machine = MA_N5200;
	} else {
		machine = MA_MSOTHER;
	}
	return;
# endif		/* NOT X68K */
#endif		/* MSDOS */
}


/*
 *	moveto() - cursor move to (x, y).
 *
 *	support machine dependent method for MSDOS machines.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
moveto(y, x)
	int		y, x;
{
#ifdef		MSDOS
# ifndef	X68K
    union REGS	regs;

	if (!ansiwrite && controlled) {
		switch (machine) {

		case MA_PC98   :
		case MA_PC98XA :
		case MA_N5200  :
			regs.h.cl = 0x10;
			regs.h.ah = 3;
 			regs.h.dl = x;
			regs.h.dh = y;
			int86(0xdc, &regs, &regs);
			break;

		case MA_PC100 :
			regs.h.cl = 0x36;
 			regs.h.dh = x;
			regs.h.dl = y;
			int86(0xdc, &regs, &regs);
			break;

		default :
			printf("%c[%d;%dH", ESC, ++y, ++x);
		}
	} else {
		printf("%c[%d;%dH", ESC, ++y, ++x);
	}
# endif		/* NOT X68K */
# ifdef		X68K
	B_LOCATE(x,y);
# endif		/* X68K */
#endif		/* MSDOS */

#ifndef	MSDOS
	printf("%c[%d;%dH", ESC, ++y, ++x);
#endif	/* NOT MSDOS */
}


/*
 *	pictureon(), pictureoff() - PC98's graphic control sequance.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
pictureon()
{
#ifdef		MSDOS
# ifndef	X68K
	union REGS	regs;

	if (machine == MA_PC98 && !ansiwrite) {
		regs.h.ah=0x40;
		int86(0x18, &regs, &regs);
	}
# endif		/* NOT X68K */
#endif		/* MSDOS */
}


#ifdef	ANSI
void
#endif	/* ANSI */
pictureoff()
{
#ifdef		MSDOS
# ifndef	X68K
	union REGS	regs;

	if (machine == MA_PC98 && !ansiwrite) {
		regs.h.ah=0x41;
		int86(0x18, &regs, &regs);
}
# endif		/* NOT X68K */
#endif		/* MSDOS */
}


/*
 *	curon(), curoff() - MSDO*'s (acturally PC98's and X68K's)
 *	cursor control sequance.
 */
#ifdef	ANSI
void
#endif	/* ANSI */
curon()
{
#ifdef		MSDOS
	if (! ansiwrite) {
# ifndef	X68K
		if (machine == MA_PC98 ||
			machine == MA_PC98XA ||
			machine == MA_N5200
		   ) {
			printf("%c[5>l", ESC);
		}
# endif		/* NOT X68K */
# ifdef		X68K
		printf("%c[>5l", ESC);				
# endif		/* X68K */
	}
#endif		/* MSDOS */
}


#ifdef	ANSI
void
#endif	/* ANSI */
curoff()
{
#ifdef		MSDOS
	if (! ansiwrite) {
# ifndef	X68K
		if (machine == MA_PC98 ||
			machine == MA_PC98XA ||
			machine == MA_N5200
		) {
			printf("%c[5>h", ESC);
		}
# endif		/* NOT X68K */
# ifdef		X68K
		printf("%c[>5h", ESC);
# endif		/* X68K */
	}
#endif		/* MSDOS */
}


#ifdef	ANSI
void
#endif	/* ANSI */
home()
{
#ifdef		MSDOS
# ifndef	X68K
	if (ansiwrite ||
		(!(machine == MA_PC98 ||
		   machine == MA_PC98XA ||
		   machine == MA_N5200
		) )
	   ) {
# endif		/* NOT X68K */
#endif		/* MSDOS */

		printf("%c[H", ESC);

#ifdef		MSDOS
# ifndef	X68K
	}
# endif		/* NOT X68K */
#endif		/* MSDOS */
}
