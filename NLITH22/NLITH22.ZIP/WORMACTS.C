/*
 *	"wormacts.c"
 *
 *		- functions describing worm's actions
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


#ifdef	ANSI
void
#endif	/* ANSI */
movewormone()
{
	if (istraining) {
		return;
	}
	if (0 < wormlen) {
		moveworm();
	} else if (wizard || rnd(500) <= erasedlines) {
		geneworm();
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
geneworm()
{
	int		y;

	if (rnd(2) == 0) {
		wormx[0] = 1;
		wormx[1] = 0;
	} else {
		wormx[0] = wellwidth - 2;
		wormx[1] = wellwidth - 1;
	}
	for (y = 0; y < welldepth; y++) {
		if (map[wormx[0]][y] == BLANK && (! flying(wormx[0], y))) {
			wormy[0] = y;
			wormy[1] = y;
			break;
		}
	}
	if (y == welldepth) {
		wormlen = 0;
	} else {
		wormlen = 2;
		map[wormx[0]][y] = wormhead;
		map[wormx[1]][y] = wormbody;
		mapattr[wormx[0]][y] =
		mapattr[wormx[1]][y] = wormalcolour;
		drawworm(wormalcolour);
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
moveworm()
{
	register int	i;
	int				headx, heady, dir, up, down, right, left;

	if (wormy[0] != welldepth - 1 && map[wormx[0]][wormy[0] + 1] == BLANK &&
		!flying(wormx[0], wormy[0] + 1)) {
		up = 1;
	} else {
		up = 0;
	}
	if (wormy[0] != 0 && map[wormx[0]][wormy[0] - 1] == BLANK &&
		!flying(wormx[0], wormy[0] - 1)) {
		down = 1;
	} else {
		down = 0;
	}
	if (wormx[0] != wellwidth - 1 && map[wormx[0] + 1][wormy[0]] == BLANK &&
		!flying(wormx[0] + 1, wormy[0])) {
		right = 1;
	} else {
		right = 0;
	}
	if (wormx[0] != 0 && map[wormx[0] - 1][wormy[0]] == BLANK &&
		!flying(wormx[0] - 1, wormy[0])) {
		left = 1;
	} else {
		left = 0;
	}

/*-- worm chokes itself. amen. --*/
	if (up + down + right + left == 0) {
		killworm();
		return;
	}

	while(TRUE) {
		dir = rnd(100);

/*-- 5% : worm wants to go upward --*/
		if (up == 1 && dir < 5) {
			headx = wormx[0];
			heady = wormy[0] + 1;
			break;
/*-- 75% : worm wants to go downward --*/
		} else if (down == 1 && dir < 80) {
			headx = wormx[0];
			heady = wormy[0] - 1;
			break;
/*-- 10% : worm wants to go right --*/
		} else if (right == 1 && dir < 90) {
			headx = wormx[0] + 1;
			heady = wormy[0];
			break;
/*-- 10% : worm wants to go left --*/
		} else if (left == 1) {
			headx = wormx[0] - 1;
			heady = wormy[0];
			break;
		}
	}
	for (i = wormlen; 0 < i; i--) {
		wormx[i] = wormx[i - 1];
		wormy[i] = wormy[i - 1];
	}
	wormx[0] = headx;
	wormy[0] = heady;

	colour(wormalcolour);
	wmoveto(wormy[0], wormx[0]);
	putchar(wormhead);
	map[wormx[0]][wormy[0]] = wormhead;
	mapattr[wormx[0]][wormy[0]] = wormalcolour;
	wmoveto(wormy[1], wormx[1]);
	putchar(wormbody);
	map[wormx[1]][wormy[1]] = wormbody;
	mapattr[wormx[1]][wormy[1]] = wormalcolour;
	norm();
	if (wormlen < WORMLEN_MAX && rnd(10) == 0) {
		wormlen++;
	} else {
		wmoveto(wormy[wormlen], wormx[wormlen]);
		putchar(BLANK);
		map[wormx[wormlen]][wormy[wormlen]] = BLANK;
	}
}


/*
 *	check if worm is colliding with flying block
 */
BOOLEAN
flying(x, y)
	int		x, y;
{
	register int	i;

	for (i = 0; i < lithn; i++) {
		if ((x & ~(1)) == moving.x[i] && y == moving.y[i]) {
			return (TRUE);
		}
	}
	return (FALSE);
}


#ifdef	ANSI
void
#endif	/* ANSI */
killworm()
{
	register int	i;

	drawworm(wormcolour);
	for (i = 0; i < wormlen; i++) {
		mapattr[wormx[i]][wormy[i]] = wormcolour;
		if (map[wormx[i] ^ 1][wormy[i]] == BLANK) {
			map[wormx[i] ^ 1][wormy[i]] = wormspilit;
			mapattr[wormx[i] ^ 1][wormy[i]] = wormspcolour;
			wmoveto(wormy[i], wormx[i] ^ 1);
			colour(wormspcolour);
			printf("%c", wormspilit);
			norm();
		}
	}
	wormlen = 0;
	checkstack();
}


#ifdef	ANSI
void
#endif	/* ANSI */
drawworm(colourcode)
	int		colourcode;
{
	register int	i;

	colour(colourcode);
	wmoveto(wormy[0], wormx[0]);
	printf("%c", wormhead);
	for (i = 1; i < wormlen; i++) {
		wmoveto(wormy[i], wormx[i]);
		printf("%c", wormbody);
	}
	norm();
}

#ifdef	NEVER
#ifdef	ANSI
void
#endif	/* ANSI */
vdrawworm()
{
	register int	i;

	map[wormx[0]][wormy[0]] = wormhead;
	mapattr[wormx[0]][wormy[0]] = wormalcolour;
	for (i = 1; i < wormlen; i++) {
		map[wormx[i]][wormy[i]] = wormbody;
		mapattr[wormx[i]][wormy[i]] = wormalcolour;
		printf("%c", BLANK);
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
veraseworm()
{
	register int	i;

	for (i = 0; i < wormlen; i++) {
		map[wormx[i]][wormy[i]] = BLANK;
	}
}
#endif
