/*
 *	"lithacts.c"
 *
 *		- describing lith's action
 *		  for nlith $Revision: 2.2 $.
 *
 *	caution : all rights are reserved by Taroh Sasaki, 1988.
 *
 *	all modules including this file are COMPLETELY PUBLIC DOMAIN,
 *	under distribution of WHOLE MODULE SOURCES.
 *	author owe no duty about this program's effects.
 *
 *	see document "nlith.man" for detail.
 */

#include	"nlith.h"


BOOLEAN
genelith()
{
	int				pattern, minx, maxx, maxy, biasx, biasy,
					j, retry;
	register int	i;

	for (retry = 0; retry < 5; retry++) {

/*
 *	decide howmany-LITH should be generated.
 */
		if (istraining) {
			lithn = LITHN_DEF;
		} else if (genn != 0) {
			lithn = genn;
		} else {
			j = rnd(100);
			for (i = LITHN_MIN - 1; i < LITHN_MAX; i++) {
				if (j < factn[i]) {
					lithn = i + 1;
					break;
				}
			}
		}
		pattern = basinfo[lithn - 1] + rnd(patinfo[lithn - 1]);
	
/*
 *	copy initial pattern from constant to "moving."
 */
		for (i = 0; i < lithn; i++) {
			moving.x[i] = iniinfo[pattern].shape.x[i];
			moving.x[i] <<= 1;	/* convert from block's address to worm's. */
			moving.y[i] = iniinfo[pattern].shape.y[i];
		}
		moving.rotp = iniinfo[pattern].shape.rotp;
		moving.ch1  = iniinfo[pattern].shape.ch1;
		moving.ch2  = iniinfo[pattern].shape.ch2;
		moving.attr = iniinfo[pattern].shape.attr;
	
/*
 *	randomize "moving's" direction.
 */
		for (i = 0; i < rnd(4); i++) {
			rrotlith(&moving);
		}
	
/*
 *	adjust initial position.
 */
		maxx =
		maxy = -99;
		minx = 99;
		for (i = 0; i < lithn; i++) {
			if (maxx < moving.x[i]) {
				maxx = moving.x[i];
			}
			if (moving.x[i] < minx) {
				minx = moving.x[i];
			}
			if (maxy < moving.y[i]) {
				maxy = moving.y[i];
			}
		}
		minx >>= 1;
		maxx >>= 1;
		biasy = welldepth - maxy - 1;
		biasx = (rnd((wellwidth >> 1) - maxx + minx) - minx) << 1;
		for (i = 0; i < lithn; i++) {
			moving.x[i] += biasx;
			moving.y[i] += biasy;
		}
	
		if (!collision(&moving)) {
			drawlith(&moving);
			fallen = FALSE;
			return (TRUE);
		}
	}
	return (FALSE);
}


BOOLEAN
droplith(isdraw)
	BOOLEAN	isdraw;
{
	struct LITH		test;
	register int	i;

	for (i = 0; i < lithn; i++) {
		test.x[i] = moving.x[i];
		test.y[i] = moving.y[i] - 1;
	}
	if (collision(&test)) {
		return (FALSE);
	}

	if (isdraw) {
		eraselith(&moving);
	}
	for (i = 0; i < lithn; i++) {
		moving.x[i] = test.x[i];
		moving.y[i] = test.y[i];
	}
	if (isdraw) {
		drawlith(&moving);
	}

	return (TRUE);
}


BOOLEAN
rotlith()			/* rotate-right 'moving', if available. */
{
	struct LITH		afterrot;	/* no touched to ch?, attr field */
	register int	i;
	int				cnt, rotnum, cha;
	char			ch;

	for (i = 0; i < lithn; i++) {
		afterrot.x[i] = moving.x[i];
		afterrot.y[i] = moving.y[i];
	}
	afterrot.rotp = moving.rotp;
	if (isevil(80)) {
		rotnum = rnd(4);
		dispstrings(9);		/* evil rotation */
	} else {
		rotnum = rotincr;
	}
	for (cnt = 0; cnt < rotnum; cnt++) {
		rrotlith(&afterrot);
	}
	if (collision(&afterrot)) {
		return (FALSE);
	}

	eraselith(&moving);
	for (i = 0; i < lithn; i++) {
		moving.x[i] = afterrot.x[i];
		moving.y[i] = afterrot.y[i];
	}
	moving.rotp = afterrot.rotp;
	drawlith(&moving);
	for (i = 0; i < lithn; i++) {
		if (welldepth <= moving.y[i] + 1) {
			continue;
		}
		ch = map[moving.x[i]][moving.y[i] + 1];
		cha = mapattr[moving.x[i]][moving.y[i] + 1];
		if (ch == BLANK) {
			continue;	/* above the particle is brank */
		}
		if (!((ch == wormbody || ch == wormhead) && cha == wormalcolour)) {
			break;		/* above the block is another block or dead worm */
		}
	}
	if (i < lithn) {
		upscore();
		upscore();
		upscore();
		upscore();
		dispstrings(17);	/* fill an eaves */
	} else if (fallen) {
		dispstrings(16);	/* adjust position */
	}

	return (TRUE);
}


#ifdef	ANSI
void
#endif	/* ANSI */
rrotlith(test)			/* force right-rotation of 'test' */
	struct LITH	*test;
{
	register int	i;

	for (i = 0; i < lithn; i++) {
		test -> x[i] = test -> x[i] + (((test -> rotp) -> x[i]) << 1);
		test -> y[i] = test -> y[i] + (test -> rotp) -> y[i];
	}
	test -> rotp = (test -> rotp) -> next;
}


BOOLEAN
swinglith(vector)
	int		vector;
{
	struct LITH		afterswing;	/* no touch to ch?, attr field of afterswing */
	register int	i;
	int				evil, cha;
	char			ch;

	if (isevil(100)) {
		evil = ((rnd(2) == 0 ? 1 : -1) << 1);
		dispstrings(6);		/* evil swing */
	} else {
		evil = 0;
	}

	for (i = 0; i < lithn; i++) {
		afterswing.x[i] = moving.x[i] + vector + evil;
		afterswing.y[i] = moving.y[i];
	}
	if (collision(&afterswing)) {
		return (FALSE);
	}

	eraselith(&moving);
	for (i = 0; i < lithn; i++) {
		moving.x[i] = afterswing.x[i];
		moving.y[i] = afterswing.y[i];
	}
	drawlith(&moving);
	for (i = 0; i < lithn; i++) {
		if (welldepth <= moving.y[i] + 1) {
			continue;
		}
		ch = map[moving.x[i]][moving.y[i] + 1];
		cha = mapattr[moving.x[i]][moving.y[i] + 1];
		if (ch == BLANK) {
			continue;	/* above the particle is brank */
		}
		if (!((ch == wormbody || ch == wormhead) && cha == wormalcolour)) {
			break;		/* above the block is another block or dead worm */
		}
	}
	if (i < lithn) {
		upscore();
		upscore();
		dispstrings(17);	/* fill an eaves */
	} else if (fallen) {
		dispstrings(16);	/* adjust position */
	}

	return (TRUE);
}


#ifdef	ANSI
void
#endif	/* ANSI */
polylith()
{
	register int	i;
	int				pattern, biasx, biasy;
	struct LITH		newlith;

	pattern = basinfo[lithn - 1] + rnd(patinfo[lithn - 1]);

/*
 *	copy initial pattern from constant to "moving."
 */
	if (!isholy()) {
		return;
	}
	dispstrings(10);		/* polymonoph */
	for (i = 0; i < lithn; i++) {
		newlith.x[i] = iniinfo[pattern].shape.x[i] << 1;
			/* convert from block's address to worm's. */;
		newlith.y[i] = iniinfo[pattern].shape.y[i];
	}
	newlith.rotp = iniinfo[pattern].shape.rotp;
	newlith.ch1  = iniinfo[pattern].shape.ch1;
	newlith.ch2  = iniinfo[pattern].shape.ch2;
	newlith.attr = iniinfo[pattern].shape.attr;

/*
 *	randomize "newlith's" direction.
 */
	for (i = 0; i < rnd(4); i++) {
		rrotlith(&newlith);
	}

	biasx = moving.x[0] - newlith.x[0];
	biasy = moving.y[0] - newlith.y[0];
	for (i = 0; i < lithn; i++) {
		newlith.x[i] += biasx;
		newlith.y[i] += biasy;
	}
	if (!collision(&newlith)) {
		holypoint -= 4;
		eraselith(&moving);
#ifndef	ANSI
		for (i = 0; i < lithn; i++) {
			moving.x[i] = newlith.x[i];
			moving.y[i] = newlith.y[i];
		}
		moving.rotp = newlith.rotp;
		moving.ch1  = newlith.ch1;
		moving.ch2  = newlith.ch2;
		moving.attr = newlith.attr;
#endif	/* NOT ANSI */
#ifdef	ANSI
		moving = newlith;
#endif	/* ANSI */
		drawlith(&moving);
	}
}


#ifdef	ANSI
void
#endif	/* ANSI */
falllith()
{
	int		fallheight, i, ch;
	char	cha;

	if (isjump) {
		eraselith(&moving);
	}
	fallheight = moving.y[0];
	while(droplith(!isjump)) {
		/*** fallllllllling ... ***/
	}
	fallheight -= moving.y[0];
	if (isjump) {
		drawlith(&moving);
	}
	if (0 < fallheight) {
		fallen = TRUE;
	}

	/*** fall bonus ***/
	if (isjump) {
		if (rnd(80) < fallheight) {
			dispstrings(13);	/* fall a block (2) */
			holypoint++;
		}
		if (rnd(20) < fallheight) {
			dispstrings(3);		/* fall a block (1) */
			score++;
		}
	} else {
		if (rnd(160) < fallheight) {
			dispstrings(13);	/* fall a block (2) */
			holypoint++;
		}
		if (rnd(40) < fallheight) {
			dispstrings(3);		/* fall a block (1) */
			score++;
		}
	}
	if (0 < wormlen) {
		for (i = 0; i < lithn; i++) {
			if (moving.y[i] == 0) {
				break;		/* the block is on the ground */
			}
			ch = map[moving.x[i]][moving.y[i] - 1];
			cha = mapattr[moving.x[i]][moving.y[i] - 1];
			if (ch == BLANK) {
				continue;	/* the particle is in the air */
			}
			if (!((ch == wormbody || ch == wormhead) && cha == wormalcolour)) {
				break;		/* the block is on another block or dead worm */
			}
		}
		if (i == lithn && rnd(100) < fallheight * lithn) {
			killworm();			/* pressed a worm */
			evilpoint++;
			dispstrings(4);		/* kill a worm */
		}
	}
}


BOOLEAN
collision(test)
	struct LITH	*test;
{
	register int	i;

	for (i = 0; i < lithn; i++) {
		if (map[test -> x[i]    ][test -> y[i]] != BLANK ||
			map[test -> x[i] + 1][test -> y[i]] != BLANK ||
			test -> y[i] < 0 || welldepth <= test -> y[i] ||
			test -> x[i] < 0 || wellwidth <= test -> x[i]) {
			return (TRUE);
		}
	}
	return (FALSE);
}
